﻿using CefSharp;
using MahApps.Metro.Controls;
using System;
using System.IO;
using System.Windows;
using LibVLCSharp.Shared;
using getLocateMap.ViewModels;
using System.Diagnostics;
using System.Net;
using static OpenTK.Graphics.OpenGL.GL;
using LibVLCSharp.WPF;
using System.Text;

namespace getLocateMap
{
    /// <summary>
    /// MainWindow.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class MainWindow : MetroWindow
    {
        string locate_Html = string.Empty; // html 파일 string 값 복사해서 모달 창에 쓰기위해 할당
        private int height_val = 400;
        string CCTV_Url = "http://61.43.246.226:1935/rtplive/cctv_193.stream/playlist.m3u8";

        LibVLC _libVLC;
        MediaPlayer _mediaPlayer;

        public MainWindow()
        {
            InitializeComponent();

            // cefSharp으로 안띄워지는 CCTV를 띄우기 위한 방법
            Core.Initialize();
            // VLC NuGet 패키지를 받아서 비디오 플레이어 역할 할당.
            _libVLC = new LibVLC();
            _mediaPlayer = new MediaPlayer(_libVLC);

            CCTV_View.MediaPlayer = _mediaPlayer;

            CCTV_View.MediaPlayer.Play(new Media(_libVLC, new Uri(CCTV_Url)));
        }

        public void browser_IsBrowserInitializedChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            var map_url = $@"../../api2.html";
            string strHtml = File.ReadAllText(map_url);
            locate_Html = strHtml; // html 파일 string 값 복사해서 모달 창에 쓰기위해 할당
            // Debug.WriteLine(strHtml);
            
            browser.LoadHtml(strHtml, "https://www.team-one.com/");
        }

        private void browser_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            var locateMap = new locateMap();
            locateMap.Owner = Application.Current.MainWindow;
            locateMap.WindowStartupLocation = WindowStartupLocation.CenterOwner;
            // 여기에서 locate_Html 값 사용 193 픽셀 값 수정
            string replace_Locate_Html = locate_Html.Replace("193px", $"{height_val}px");
            locateMap.locateMap_browser.LoadHtml(replace_Locate_Html, "https://www.team-one.com/");
            locateMap.ShowDialog();
        }

        //private void MetroWindow_SizeChanged(object sender, SizeChangedEventArgs e)
        //{
        //    LblSize.Content = Grid_Browser.ActualHeight;

        //    string htmlsource = "<!DOCTYPE html>\n" +
        //        "<html>\n" +
        //        "<head>\n" +
        //        "<meta charset='utf-8'>\n" +
        //        "<title>지도 위 버튼으로 로드뷰 표시하기</title>\n" +
        //        "<style>\n" +
        //        "#container {overflow:hidden;height: "+ Grid_Browser.ActualHeight +"px;position:relative;}\n" +
        //        "#mapWrapper {width:100%;height:"+ Grid_Browser.ActualHeight +"px;z-index:1;}\n" +
        //        "#rvWrapper {width:50%;height:"+ Grid_Browser.ActualHeight +"px;top:0;right:0;position:absolute;z-index:0;}\n" +
        //        "#container.view_roadview #mapWrapper {width: 50%;}\n" +
        //        "#roadviewControl {position:absolute;top:5px;left:5px;width:42px;height:42px;z-index: 1;cursor: pointer; background: url(https://t1.daumcdn.net/localimg/localimages/07/2018/pc/common/img_search.png) 0 -450px no-repeat;}\n" +
        //        "#roadviewControl.active {background-position:0 -350px;}\n" +
        //        "#close {position: absolute;padding: 4px;top: 5px;left: 5px;cursor: pointer;background: #fff;border-radius: 4px;border: 1px solid #c8c8c8;box-shadow: 0px 1px #888;}\n" +
        //        "#close .img {display: block;background: url(https://t1.daumcdn.net/localimg/localimages/07/mapapidoc/rv_close.png) no-repeat;width: 14px;height: 14px;}\n" +
        //        "</style>\n" +
        //        "</head>\n" +
        //        "<script src='api2.js'></script>\n" +
        //        "<body>\n" +
        //        "<div id='container'>\n" +
        //        "    <div id='rvWrapper'>\n" +
        //        "        <div id='roadview' style='width:100%;height:100%;'></div> <!-- 로드뷰를 표시할 div 입니다 -->\n" +
        //        "        <div id='close' title='로드뷰닫기' onclick='closeRoadview()'><span class='img'></span></div>\n" +
        //        "    </div>\n" +
        //        "    <div id='mapWrapper'>\n" +
        //        "        <div id='map' style='width:100%;height:100%'></div> <!-- 지도를 표시할 div 입니다 -->\n" +
        //        "        <div id='roadviewControl' onclick='setRoadviewRoad()'></div>\n" +
        //        "    </div>\n" +
        //        "</div>\n" +
        //        "<script type='text/javascript' src='//dapi.kakao.com/v2/maps/sdk.js?appkey=a71fd4e07d867d250dec31c7fa8e7742'></script>" +
        //        "<script src='map.js'></script>\n" +
        //        "</body>\n" +
        //        "</html>";
            
        //    System.IO.File.WriteAllText($@"{AppDomain.CurrentDomain.BaseDirectory}..\..\api2.html", htmlsource, Encoding.UTF8);
        //    Debug.WriteLine("HTML file saved...");

        //    int Grid_Browser_ActualHeight = (int)Grid_Browser.ActualHeight;

        //    var map_url = $@"../../api2.html";
        //    string strHtml = File.ReadAllText(map_url);
        //    locate_Html = strHtml; // html 파일 string 값 복사해서 모달 창에 쓰기위해 할당
        //                           // Debug.WriteLine(strHtml);

        //    browser.LoadHtml(strHtml, "https://www.team-one.com/");
        //}
    }
}

